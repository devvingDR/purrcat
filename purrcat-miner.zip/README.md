# PURRCAT GPU miner (HyperEVM)

Mine des chats sur https://purrcat.xyz/ avec un GPU. Contrat `0xC8f09BC3C084Acfd5c5472F3d91A53D3843f833f`
(HyperEVM, chain 999), 3333 chats. **Mint GRATUIT** : tu ne paies que le gaz en HYPE.

```
challenge = keccak256(abi.encode(blockhash(anchorBlock), prevWork))
hash = keccak256(abi.encode(DOMAIN, 999, purrcat, challenge, ton_adresse, nonce))
valide si hash <= yourTarget (cible par wallet, ~2^38 hashes)
tir : mine(anchorBlock, nonce, maxPrice)
```

Chaque chat du reseau relance la course pour tout le monde : le premier qui trouve rafle le chat.
Ta cible durcit quand tu gagnes d'affilee : avec plusieurs wallets (`PKS=`), le driver mine
toujours avec celle qui a la cible la plus facile.

## Installation (Linux + GPU NVIDIA, Ubuntu)

1. Envoie le zip sur ta machine GPU (depuis ton PC, dans PowerShell) :
```bash
scp -P PORT purrcat-miner.zip root@IP:~/
```
(PORT et IP = ceux de ta commande SSH de location. Ou glisse le fichier dans Jupyter / l interface de ton rig.)

2. Sur la machine GPU (en SSH) :
```bash
cd ~ && (command -v unzip >/dev/null || (apt-get update -qq && apt-get install -y -qq unzip)) && unzip -oq purrcat-miner.zip -d purrcat && cd purrcat && bash setup.sh && node driver.mjs --selftest
```
Ca doit finir sur ✅ GPU valide.

## Utilisation

```bash
export PK=0xTA_CLE_PRIVEE         # wallet avec un peu de HYPE sur HyperEVM pour le gaz
cd ~/purrcat && node driver.mjs   # simulation (aucune tx)
node driver.mjs --send            # mine pour de vrai, sans fin
PKS=0xCLE1,0xCLE2,0xCLE3 node driver.mjs --send   # plusieurs wallets en rotation
```

Options : `--count N` (s'arrete apres N chats), `--prio gwei` (defaut 0.5),
`RPC=https://...` devant la commande (ton propre RPC HyperEVM, en plus du public).

Laisser tourner apres la fermeture du terminal :
```bash
cd ~/purrcat && setsid nohup node driver.mjs --send > run.log 2>&1 < /dev/null &
tail -f ~/purrcat/run.log
```

## Depannage

| Symptome | Solution |
|---|---|
| `no OpenCL platform` | `mkdir -p /etc/OpenCL/vendors && echo libnvidia-opencl.so.1 > /etc/OpenCL/vendors/nvidia.icd` |
| `GPU N en panne` ou 0 % partout | une carte a plante : rebooter le rig, puis lancer avec `CUDA_VISIBLE_DEVICES=0,1,2,...` sans la carte fautive |
| `Segmentation fault` (vast) | `export LD_LIBRARY_PATH=/usr/lib/x86_64-linux-gnu` |
| `Cannot find package 'viem'` | `cd` dans le dossier puis `npm install viem` |
| `course perdue` / `BadProof` / `OneMintPerBlock` | normal : quelqu'un a attrape le meme chat avant toi |
