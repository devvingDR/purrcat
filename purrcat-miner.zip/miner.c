// ── PURRCAT / HATCH PoW miner (OpenCL, multi-GPU) — derive du miner Octocore ─────
//
// Preimage (decodee dans routes-*.js de xtrct.dev, VERIFIEE contre leur vecteur
// de test le 22/09/2026, viem == expectedHash) :
//   keccak256(abi.encode(address contract, uint256 chainId, address miner,
//                        bytes32 previousProof, uint256 challengeBlock, uint256 nonce))
//   = 6 mots de 32 octets = 192 octets, soit DEUX blocs keccak (rate 136) :
//     bloc 1 = octets 0..135   : tout sauf la fin -> CONSTANT pour une tache,
//                                absorbe une fois sur l'hote (etat de 25 lanes)
//     bloc 2 = octets 136..191 : challengeBlock[8..31] | nonce[32], puis le pad
//   gagnant si uint256(hash) < target (STRICT, leur `BigInt(e)<t`).
// Le GPU fait varier les 8 derniers octets du nonce (octets 184..191 du message
// = octets 48..55 du bloc 2 = lane 6 du bloc 2, big-endian). Les 24 premiers
// octets du nonce sont un prefixe aleatoire fourni par le driver.
//
// Build : gcc -O2 miner.c -o miner -lOpenCL        (pas de toolkit CUDA)
// Mode serveur (le driver) :  ./miner --serve
//   stdin  : JOB <id> <state50hex...> <blk2 112hex> <target64hex>
//            (state = 25 lanes little-endian, 400 hex ; blk2 = 56 octets, nonce
//             octets 48..55 a zero, le GPU les remplit)
//   stdout : READY <gpus> | FOUND <id> <low64 decimal>
//   stderr : RATE <GH/s> <gpus> toutes les 10 s
// Mode une-passe (autotest) : ./miner <state400hex> <blk2 112hex> <target64hex> [secs]
#define CL_TARGET_OPENCL_VERSION 120
#include <CL/cl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <unistd.h>
#include <poll.h>

static const char *KSRC =
"__constant ulong RC[24]={0x0000000000000001UL,0x0000000000008082UL,0x800000000000808aUL,0x8000000080008000UL,0x000000000000808bUL,0x0000000080000001UL,0x8000000080008081UL,0x8000000000008009UL,0x000000000000008aUL,0x0000000000000088UL,0x0000000080008009UL,0x000000008000000aUL,0x000000008000808bUL,0x800000000000008bUL,0x8000000000008089UL,0x8000000000008003UL,0x8000000000008002UL,0x8000000000000080UL,0x000000000000800aUL,0x800000008000000aUL,0x8000000080008081UL,0x8000000000008080UL,0x0000000080000001UL,0x8000000080008008UL};\n"
"__constant int ROT[25]={0,1,62,28,27,36,44,6,55,20,3,10,43,25,39,41,45,15,21,8,18,2,61,56,14};\n"
"__constant int PI[25]={0,10,20,5,15,16,1,11,21,6,7,17,2,12,22,23,8,18,3,13,14,24,9,19,4};\n"
"inline ulong rol(ulong x,int n){return n? ((x<<n)|(x>>(64-n))) : x;}\n"
"inline uint bswap32(uint x){return (x<<24)|((x&0xff00u)<<8)|((x>>8)&0xff00u)|(x>>24);}\n"
"inline ulong bswap64(ulong x){return ((ulong)bswap32((uint)(x&0xffffffffUL))<<32)|(ulong)bswap32((uint)(x>>32));}\n"
"void keccakf(ulong* A){ ulong B[25],C[5],D;\n"
"#pragma unroll\n"
" for(int r=0;r<24;r++){\n"
"#pragma unroll\n"
"  for(int x=0;x<5;x++) C[x]=A[x]^A[x+5]^A[x+10]^A[x+15]^A[x+20];\n"
"#pragma unroll\n"
"  for(int x=0;x<5;x++){ D=C[(x+4)%5]^rol(C[(x+1)%5],1); for(int y=0;y<25;y+=5) A[y+x]^=D; }\n"
"#pragma unroll\n"
"  for(int i=0;i<25;i++) B[PI[i]]=rol(A[i],ROT[i]);\n"
"#pragma unroll\n"
"  for(int y=0;y<25;y+=5){ for(int x=0;x<5;x++) A[y+x]=B[y+x]^((~B[y+((x+1)%5)])&B[y+((x+2)%5)]); }\n"
"  A[0]^=RC[r]; } }\n"
// base = 25 lanes (etat apres le bloc 1) puis 7 lanes (bloc 2, lane 6 sans le nonce)
"__kernel void mine(__global ulong* base, ulong t0,ulong t1,ulong t2,ulong t3, uint startLo,uint startHi, uint iter, __global uint* res){\n"
" uint gid=get_global_id(0);\n"
" for(uint k=0;k<iter;k++){\n"
"  uint off=gid*iter+k; ulong n=(((ulong)startHi<<32)|startLo)+off;\n"
"  ulong s[25]; for(int i=0;i<25;i++) s[i]=base[i];\n"
"  for(int i=0;i<6;i++) s[i]^=base[25+i];\n"
"  s[6]^=base[31]|bswap64(n);\n"                       // nonce low 64 bits, big-endian dans la lane 6
"  s[7]^=0x01UL; s[16]^=0x8000000000000000UL;\n"       // pad keccak : octet 56 = 0x01, octet 135 |= 0x80
"  keccakf(s);\n"
"  ulong D0=bswap64(s[0]), D1=bswap64(s[1]), D2=bswap64(s[2]), D3=bswap64(s[3]);\n"
"  bool ok = (D0<t0) || (D0==t0 && (D1<t1 || (D1==t1 && (D2<t2 || (D2==t2 && D3<t3)))));\n"
"  if(ok){ if(atomic_cmpxchg(&res[0],0u,1u)==0u){res[1]=(uint)(n&0xffffffffUL);res[2]=(uint)(n>>32);} return; }\n"
" }\n"
"}\n";

static unsigned hexbyte(const char*h,int i){char b[3]={h[i*2],h[i*2+1],0};return (unsigned)strtoul(b,0,16);}
static const char* strip0x(const char*s){ return (!strncmp(s,"0x",2)||!strncmp(s,"0X",2))? s+2 : s; }
// state400hex (25 lanes LE, 8 octets chacune) + blk2 112hex (56 octets) + target -> base[32], tw[4]
static int build(const char*st,const char*b2,const char*tg, uint64_t base[32], uint64_t tw[4]){
  st=strip0x(st); b2=strip0x(b2); tg=strip0x(tg);
  if(strlen(st)!=400||strlen(b2)!=112) return 0;
  for(int l=0;l<25;l++){ uint64_t v=0; for(int b=0;b<8;b++) v|=((uint64_t)hexbyte(st,l*8+b))<<(8*b); base[l]=v; }
  unsigned char blk[56]; for(int i=0;i<56;i++) blk[i]=hexbyte(b2,i);
  for(int l=0;l<7;l++){ uint64_t v=0; for(int b=0;b<8;b++) v|=((uint64_t)blk[8*l+b])<<(8*b); base[25+l]=v; }
  base[31]&=0x0ULL;   // lane 6 = octets 48..55 = les 8 octets bas du nonce : entierement au GPU
  unsigned char tb[32]; char full[65]; memset(full,'0',64); full[64]=0; int tl=strlen(tg); if(tl>64)tl=64; memcpy(full+64-tl,tg+(strlen(tg)-tl),tl);
  for(int i=0;i<32;i++) tb[i]=hexbyte(full,i);
  for(int w=0;w<4;w++){ uint64_t v=0; for(int b=0;b<8;b++) v=(v<<8)|tb[w*8+b]; tw[w]=v; }
  return 1;
}

typedef struct { cl_uint nd; cl_context ctx; cl_command_queue q[32]; cl_kernel k[32]; cl_mem rb[32], bb[32]; uint32_t bhi[32], blo[32]; } GPU;
static int gpu_init(GPU*g){
  cl_platform_id plats[8]; cl_uint np=0; if(clGetPlatformIDs(8,plats,&np)!=CL_SUCCESS||!np){fprintf(stderr,"no OpenCL platform\n");return 0;}
  cl_platform_id plat=plats[0]; g->nd=0;
  for(cl_uint p=0;p<np;p++){ cl_uint c=0; if(clGetDeviceIDs(plats[p],CL_DEVICE_TYPE_GPU,0,0,&c)==CL_SUCCESS&&c){plat=plats[p];g->nd=c;break;} }
  if(!g->nd){fprintf(stderr,"no gpu\n");return 0;}
  cl_device_id devs[32]; if(g->nd>32)g->nd=32; clGetDeviceIDs(plat,CL_DEVICE_TYPE_GPU,g->nd,devs,0);
  cl_int e; g->ctx=clCreateContext(0,g->nd,devs,0,0,&e);
  cl_program prog=clCreateProgramWithSource(g->ctx,1,&KSRC,0,&e);
  e=clBuildProgram(prog,g->nd,devs,"",0,0);
  if(e){char log[16384];clGetProgramBuildInfo(prog,devs[0],CL_PROGRAM_BUILD_LOG,sizeof log,log,0);fprintf(stderr,"build %d:\n%s\n",e,log);return 0;}
  for(cl_uint d=0;d<g->nd;d++){ g->q[d]=clCreateCommandQueue(g->ctx,devs[d],0,&e); g->k[d]=clCreateKernel(prog,"mine",&e); g->rb[d]=clCreateBuffer(g->ctx,CL_MEM_READ_WRITE,3*4,0,&e); g->bb[d]=clCreateBuffer(g->ctx,CL_MEM_READ_ONLY,32*8,0,&e); }
  return 1;
}
static void gpu_load(GPU*g, uint64_t base[32]){
  srand((unsigned)time(0)^getpid()^(unsigned)clock());
  for(cl_uint d=0;d<g->nd;d++){ clEnqueueWriteBuffer(g->q[d],g->bb[d],CL_TRUE,0,32*8,base,0,0,0);
    uint64_t s0=((uint64_t)(((uint32_t)rand()<<16)^rand())<<32)|(uint32_t)(((uint32_t)rand()<<16)^rand()); s0+=(uint64_t)d*0x1000000000UL; g->bhi[d]=s0>>32; g->blo[d]=(uint32_t)s0; }
}
// une passe sur tous les GPU ; rend 1 + nonce si trouve
static int gpu_pass(GPU*g, uint64_t tw[4], uint64_t*found, uint64_t*hashed){
  size_t GLOBAL=1u<<20; uint32_t ITER=128; uint64_t span=(uint64_t)GLOBAL*ITER; uint32_t zero=0;
  for(cl_uint d=0;d<g->nd;d++){ clEnqueueWriteBuffer(g->q[d],g->rb[d],CL_FALSE,0,4,&zero,0,0,0); clSetKernelArg(g->k[d],0,sizeof(cl_mem),&g->bb[d]); clSetKernelArg(g->k[d],1,8,&tw[0]);clSetKernelArg(g->k[d],2,8,&tw[1]);clSetKernelArg(g->k[d],3,8,&tw[2]);clSetKernelArg(g->k[d],4,8,&tw[3]); clSetKernelArg(g->k[d],5,4,&g->blo[d]);clSetKernelArg(g->k[d],6,4,&g->bhi[d]);clSetKernelArg(g->k[d],7,4,&ITER);clSetKernelArg(g->k[d],8,sizeof(cl_mem),&g->rb[d]); clEnqueueNDRangeKernel(g->q[d],g->k[d],1,0,&GLOBAL,0,0,0,0); }
  int hit=0;
  for(cl_uint d=0;d<g->nd;d++){ uint32_t r[3]={0,0,0}; cl_int re=clEnqueueReadBuffer(g->q[d],g->rb[d],CL_TRUE,0,12,r,0,0,0); if(re!=CL_SUCCESS){ fprintf(stderr,"GPU %u en panne (OpenCL %d) : relancer en l ecartant (CUDA_VISIBLE_DEVICES)\n",d,re); fflush(stderr); exit(3); } *hashed+=span;
    if(r[0]==1&&!hit){ *found=((uint64_t)r[2]<<32)|r[1]; hit=1; }
    uint64_t nb=(((uint64_t)g->bhi[d]<<32)|g->blo[d])+span; g->bhi[d]=nb>>32; g->blo[d]=(uint32_t)nb; }
  return hit;
}

static int serve(void){
  GPU g; if(!gpu_init(&g)) return 1;
  fprintf(stderr,"READY gpus=%u\n",g.nd); printf("READY %u\n",g.nd); fflush(stdout); fflush(stderr);
  uint64_t base[32], tw[4]; char id[64]="", nid[64]; int have=0, paused=0;
  char buf[16384]; size_t blen=0; uint64_t total=0;
  struct timespec tr; clock_gettime(CLOCK_MONOTONIC,&tr);
  for(;;){
    struct pollfd pf={0,POLLIN,0};
    int pr=poll(&pf,1,(have&&!paused)?0:50);
    if(pr>0){
      ssize_t n=read(0,buf+blen,sizeof(buf)-1-blen);
      if(n<=0) return 0;
      blen+=n; buf[blen]=0;
      char*last=0,*s=buf,*nl;
      while((nl=strchr(s,'\n'))){ *nl=0; if(!strncmp(s,"JOB ",4)) last=s; s=nl+1; }
      if(last){ char st[512],b2[256],tg[128]; uint64_t nb[32],nt[4];
        if(sscanf(last,"JOB %63s %511s %255s %127s",nid,st,b2,tg)==4 && build(st,b2,tg,nb,nt)){ memcpy(base,nb,sizeof base); memcpy(tw,nt,sizeof tw); strcpy(id,nid); have=1; paused=0; gpu_load(&g,base); }
        else fprintf(stderr,"bad job line\n"); }
      size_t rest=strlen(s); memmove(buf,s,rest); blen=rest; buf[blen]=0;
    }
    if(!have||paused) continue;
    uint64_t found=0; if(gpu_pass(&g,tw,&found,&total)){ printf("FOUND %s %llu\n",id,(unsigned long long)found); fflush(stdout); paused=1; }
    struct timespec t1; clock_gettime(CLOCK_MONOTONIC,&t1); double el=(t1.tv_sec-tr.tv_sec)+(t1.tv_nsec-tr.tv_nsec)/1e9;
    if(el>=10.0){ fprintf(stderr,"RATE %.2f %u\n",total/el/1e9,g.nd); fflush(stderr); total=0; tr=t1; }
  }
}

int main(int argc,char**argv){
  if(argc>=2&&!strcmp(argv[1],"--serve")) return serve();
  if(argc<4){fprintf(stderr,"usage: %s --serve | <state400hex> <blk2_112hex> <target64hex> [seconds]\n",argv[0]);return 2;}
  uint64_t base[32], tw[4]; if(!build(argv[1],argv[2],argv[3],base,tw)){fprintf(stderr,"bad args\n");return 2;}
  double limit=argc>4?atof(argv[4]):8.0;
  GPU g; if(!gpu_init(&g)) return 1; gpu_load(&g,base);
  struct timespec t0; clock_gettime(CLOCK_MONOTONIC,&t0); uint64_t total=0, found=0;
  for(;;){
    if(gpu_pass(&g,tw,&found,&total)){ struct timespec t1; clock_gettime(CLOCK_MONOTONIC,&t1); double el=(t1.tv_sec-t0.tv_sec)+(t1.tv_nsec-t0.tv_nsec)/1e9; fprintf(stderr,"rate=%.2f GH/s gpus=%u\n",total/el/1e9,g.nd); printf("FOUND %llu\n",(unsigned long long)found); fflush(stdout); return 0; }
    struct timespec t1; clock_gettime(CLOCK_MONOTONIC,&t1); double el=(t1.tv_sec-t0.tv_sec)+(t1.tv_nsec-t0.tv_nsec)/1e9;
    if(el>=limit){ fprintf(stderr,"NONE rate=%.2f GH/s gpus=%u\n",total/el/1e9,g.nd); printf("NONE\n"); fflush(stdout); return 0; }
  }
}
