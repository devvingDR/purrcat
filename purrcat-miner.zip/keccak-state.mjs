// Keccak-f[1600] en JS pur (BigInt) : sert a absorber le bloc 1 (constant) sur
// l'hote et a passer au GPU l'etat de 25 lanes. Verifie contre viem.keccak256
// par driver.mjs --selftest (le hash final doit etre identique).
const RC = [0x0000000000000001n,0x0000000000008082n,0x800000000000808an,0x8000000080008000n,0x000000000000808bn,0x0000000080000001n,0x8000000080008081n,0x8000000000008009n,0x000000000000008an,0x0000000000000088n,0x0000000080008009n,0x000000008000000an,0x000000008000808bn,0x800000000000008bn,0x8000000000008089n,0x8000000000008003n,0x8000000000008002n,0x8000000000000080n,0x000000000000800an,0x800000008000000an,0x8000000080008081n,0x8000000000008080n,0x0000000080000001n,0x8000000080008008n]
const ROT = [0,1,62,28,27,36,44,6,55,20,3,10,43,25,39,41,45,15,21,8,18,2,61,56,14]
const PI = [0,10,20,5,15,16,1,11,21,6,7,17,2,12,22,23,8,18,3,13,14,24,9,19,4]
const M = (1n << 64n) - 1n
const rol = (x, n) => n ? (((x << BigInt(n)) | (x >> BigInt(64 - n))) & M) : x
export function keccakf(A) {
  for (let r = 0; r < 24; r++) {
    const C = [0, 1, 2, 3, 4].map(x => A[x] ^ A[x + 5] ^ A[x + 10] ^ A[x + 15] ^ A[x + 20])
    for (let x = 0; x < 5; x++) { const D = C[(x + 4) % 5] ^ rol(C[(x + 1) % 5], 1); for (let y = 0; y < 25; y += 5) A[y + x] ^= D }
    const B = new Array(25); for (let i = 0; i < 25; i++) B[PI[i]] = rol(A[i], ROT[i])
    for (let y = 0; y < 25; y += 5) for (let x = 0; x < 5; x++) A[y + x] = B[y + x] ^ ((~B[y + ((x + 1) % 5)] & M) & B[y + ((x + 2) % 5)])
    A[0] ^= RC[r]
  }
  return A
}
const laneLE = (buf, off) => { let v = 0n; for (let b = 7; b >= 0; b--) v = (v << 8n) | BigInt(buf[off + b] ?? 0); return v }
/** Etat (25 lanes) apres absorption du bloc 1 = les 136 premiers octets du message. */
export function stateAfterBlock1(msg) {
  const A = new Array(25).fill(0n)
  for (let l = 0; l < 17; l++) A[l] ^= laneLE(msg, l * 8)
  return keccakf(A)
}
export const stateHex = A => A.map(v => { let s = ''; for (let b = 0; b < 8; b++) s += ((v >> BigInt(8 * b)) & 0xffn).toString(16).padStart(2, '0'); return s }).join('')
/** Hash complet (2 blocs) : pour l'autotest, compare a viem. */
export function keccak2blocks(msg) {
  const A = stateAfterBlock1(msg)
  const blk2 = Buffer.alloc(136); msg.copy(blk2, 0, 136, 192); blk2[56] ^= 0x01; blk2[135] |= 0x80
  for (let l = 0; l < 17; l++) A[l] ^= laneLE(blk2, l * 8)
  keccakf(A)
  let out = '0x'; for (let l = 0; l < 4; l++) for (let b = 0; b < 8; b++) out += ((A[l] >> BigInt(8 * b)) & 0xffn).toString(16).padStart(2, '0')
  return out
}
