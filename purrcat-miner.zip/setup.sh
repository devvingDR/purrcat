#!/bin/bash
# Installation sur un rig Linux NVIDIA (Clore / vast) : deps, OpenCL, compilation, viem. Puis : node driver.mjs --selftest
set -e
cd "$(dirname "$0")"
export DEBIAN_FRONTEND=noninteractive
if ! command -v gcc >/dev/null || ! [ -f /usr/include/CL/cl.h ]; then
  apt-get update -qq && apt-get install -y -qq gcc ocl-icd-opencl-dev opencl-headers >/dev/null
fi
if ! command -v node >/dev/null || ! command -v npm >/dev/null; then apt-get update -qq; apt-get install -y -qq nodejs npm >/dev/null; fi
mkdir -p /etc/OpenCL/vendors && [ -f /etc/OpenCL/vendors/nvidia.icd ] || echo libnvidia-opencl.so.1 > /etc/OpenCL/vendors/nvidia.icd
gcc -O2 miner.c -o miner -lOpenCL
[ -d node_modules/viem ] || { [ -f package.json ] || npm init -y >/dev/null; npm install --silent viem >/dev/null; }
echo "compile OK, node $(node -v), viem $(node -e "console.log(require('viem/package.json').version)")"
nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | sort | uniq -c || true
