// ── PURRCAT (purrcat.xyz) — driver du miner GPU, HyperEVM 999 ──────────────────
//
// Mecanique (decodee le 27/09/2026, preimage VERIFIEE contre digestOf() du contrat) :
//   challenge = keccak256(abi.encode(bytes32 blockhash(anchorBlock), bytes32 prevWork))
//   hash = keccak256(abi.encode(bytes32 DOMAIN, uint256 999, address purrcat, bytes32 challenge, address miner, uint256 nonce))
//   valide si hash <= yourTarget (cible PAR WALLET, state(me)) ; anchorBlock = bloc HyperEVM, fenetre 250 blocs
//   tir : mine(anchorBlock, nonce, maxPrice) payable, value = price (0 : mint GRATUIT, seulement le gaz)
//   prevWork change a CHAQUE chat du reseau -> course ; OneMintPerBlock ; 3333 chats
//   la cible d'une wallet durcit avec sa streak : plusieurs cles (PKS) = on mine toujours avec la plus facile
//
//   node driver.mjs --selftest                      # verifie le GPU (aucune tx)
//   PK=0x... node driver.mjs                        # SIMULATION (aucune tx)
//   PK=0x... node driver.mjs --send                 # mine pour de vrai, sans fin (--count N pour s'arreter)
//   PKS=0xA,0xB,0xC node driver.mjs --send          # plusieurs wallets : rotation sur la cible la plus facile
// Options : --count N, --prio <gwei> (defaut 0.5), --poll <ms> (defaut 700), --max-price <HYPE> (defaut 0), RPC=... (RPC en plus)
import { spawn } from 'node:child_process'
import { randomBytes } from 'node:crypto'
import { createInterface } from 'node:readline'
import { fileURLToPath } from 'node:url'
import { createPublicClient, http, parseAbi, keccak256, encodeAbiParameters, encodeFunctionData, formatEther, formatGwei, parseGwei, parseEther } from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import { stateAfterBlock1, stateHex, keccak2blocks } from './keccak-state.mjs'

const CHAIN_ID = 999
const C = '0xC8f09BC3C084Acfd5c5472F3d91A53D3843f833f'
const READ_RPCS = [...new Set([process.env.RPC, 'https://rpc.hyperliquid.xyz/evm'].filter(Boolean))]
const SEND_RPCS = READ_RPCS
const BIN = process.env.BIN || fileURLToPath(new URL('./miner', import.meta.url))
const argv = process.argv.slice(2)
const opt = (k, d) => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : d }
const SEND = argv.includes('--send'), SELFTEST = argv.includes('--selftest')
const COUNT = Number(opt('--count', '0')) || Infinity, POLL = Math.max(300, Number(opt('--poll', '700')))
const PRIO = parseGwei(String(opt('--prio', '0.5')))
const MAX_PRICE = parseEther(String(opt('--max-price', '0')))
const GAS = 450_000n                // la limite que le site met
const ANCHOR_BACK = 3n, ANCHOR_REFRESH = 150n, ANCHOR_MAX_SEND = 240n
const KEYS = String(process.env.PKS || process.env.PK || '').split(/[,\s]+/).filter(Boolean)
if (!KEYS.length && !SELFTEST) { console.error('PK=0x<cle privee> (ou PKS=0xA,0xB,...) manquant'); process.exit(2) }

const accounts = KEYS.map(k => privateKeyToAccount(k.startsWith('0x') ? k : '0x' + k))
const chain = { id: CHAIN_ID, name: 'hyperevm', nativeCurrency: { name: 'HYPE', symbol: 'HYPE', decimals: 18 }, rpcUrls: { default: { http: [READ_RPCS[0]] } } }
const readers = READ_RPCS.map(u => createPublicClient({ chain, transport: http(u, { timeout: 4000, retryCount: 0 }) }))
const senders = SEND_RPCS.map(u => createPublicClient({ chain, transport: http(u, { timeout: 6000, retryCount: 0 }) }))
const pc = readers[0]
const ABI = parseAbi([
  'function state(address who) view returns (uint256 minted, uint256 price, bytes32 prev, uint256 baseTarget, uint256 yourTarget, uint256 field, uint256 yours, uint256 blockNumber, bool mintedThisBlock)',
  'function DOMAIN() view returns (bytes32)',
  'function MAX_SUPPLY() view returns (uint256)',
  'function startTime() view returns (uint256)',
  'function priceOf(uint256 id) view returns (uint256)',
  'function mine(uint256 anchorBlock, uint256 nonce, uint256 maxPrice) payable',
  'error BadAnchor()', 'error BadProof()', 'error OneMintPerBlock()', 'error NotStarted()', 'error SoldOut()', 'error PriceMoved(uint256 price)', 'error Underpaid(uint256 price)', 'error GateReserved(uint256 until)',
])
const rdOn = (c, functionName, args = []) => c.readContract({ address: C, abi: ABI, functionName, args })
let DOMAIN = null
const challengeOf = (blockHash, prev) => keccak256(encodeAbiParameters([{ type: 'bytes32' }, { type: 'bytes32' }], [blockHash, prev]))
const preimage = (challenge, miner, nonce) => Buffer.from(encodeAbiParameters(
  [{ type: 'bytes32' }, { type: 'uint256' }, { type: 'address' }, { type: 'bytes32' }, { type: 'address' }, { type: 'uint256' }],
  [DOMAIN, BigInt(CHAIN_ID), C, challenge, miner, nonce]).slice(2), 'hex')
const hashOf = (challenge, miner, nonce) => BigInt(keccak256(preimage(challenge, miner, nonce)))
const hex64 = n => n.toString(16).padStart(64, '0')
const bits = tg => (256 - Math.log2(Number(tg || 1n))).toFixed(1)
const short = a => a.slice(0, 6) + '…' + a.slice(-4)
const t = () => new Date().toISOString().slice(11, 23)
const log = (...a) => console.log(t(), ...a)
const sleep = ms => new Promise(r => setTimeout(r, ms))
const retry = async f => { for (let i = 0; ; i++) { try { return await f(readers[i % readers.length]) } catch (e) { if (i % 5 === 4) log('RPC :', String(e.shortMessage || e.message).split('\n')[0]); await sleep(700) } } }

function minerEnv() {
  const env = { ...process.env }, SYS = '/usr/lib/x86_64-linux-gnu'
  env.LD_LIBRARY_PATH = [SYS, ...String(env.LD_LIBRARY_PATH || '').split(':').filter(d => d && d !== SYS && !/cuda\/compat/.test(d))].join(':')
  return env
}
// Une tache pour le miner : etat apres le bloc 1 (constant) + bloc 2 (nonce bas a zero, le GPU le remplit)
function jobArgs(challenge, miner, prefix24) {
  const msg = preimage(challenge, miner, BigInt('0x' + prefix24) << 64n)
  return { state: stateHex(stateAfterBlock1(msg)), blk2: msg.subarray(136, 192).toString('hex') }
}

function oneShot(challenge, miner, target, secs) {
  const prefix = randomBytes(24).toString('hex')
  const { state, blk2 } = jobArgs(challenge, miner, prefix)
  const p = spawn(BIN, [state, blk2, hex64(target), String(secs)], { env: minerEnv() })
  let out = '', err = ''
  p.stdout.on('data', d => out += d); p.stderr.on('data', d => err += d)
  return new Promise(res => p.on('close', () => {
    const m = out.match(/FOUND\s+(\d+)/), rate = (err.match(/rate=([\d.]+) GH\/s gpus=(\d+)/) || []).slice(1)
    if (!m && !/NONE/.test(out) && err.trim()) log('miner stderr :', err.trim().slice(0, 300))
    res({ nonce: m ? (BigInt('0x' + prefix) << 64n) | BigInt(m[1]) : null, rate })
  }))
}
async function selftest() {
  DOMAIN = '0x' + randomBytes(32).toString('hex')
  let ok0 = true
  for (let i = 0; i < 20; i++) { const msg = preimage('0x' + randomBytes(32).toString('hex'), '0x' + randomBytes(20).toString('hex'), BigInt('0x' + randomBytes(32).toString('hex'))); if (keccak2blocks(msg) !== keccak256(msg)) ok0 = false }
  log(`keccak 2 blocs de l'hote vs viem : ${ok0 ? 'OK (20/20)' : '❌ FAUX'}`)
  log('autotest GPU : 5 recherches sur une cible facile, verifiees par viem')
  let ok = 0
  for (let i = 0; i < 5; i++) {
    const challenge = '0x' + randomBytes(32).toString('hex'), miner = '0x' + randomBytes(20).toString('hex'), target = 1n << 226n
    const { nonce, rate } = await oneShot(challenge, miner, target, 20)
    const good = nonce !== null && hashOf(challenge, miner, nonce) < target
    if (good) ok++
    log(`  essai ${i + 1} : ${nonce === null ? 'aucun nonce' : good ? 'OK' : '❌ FAUX (le GPU calcule mal)'}  ${rate[0] ? rate[0] + ' GH/s sur ' + rate[1] + ' GPU' : ''}`)
  }
  log(ok === 5 && ok0 ? '✅ GPU valide : les nonces trouves sont justes' : `❌ ${5 - ok}/5 en echec : NE PAS miner avec ce binaire`)
  process.exit(ok === 5 && ok0 ? 0 : 1)
}

async function main() {
  if (SELFTEST) return selftest()
  const [dom, max, start] = await retry(c => Promise.all([rdOn(c, 'DOMAIN'), rdOn(c, 'MAX_SUPPLY'), rdOn(c, 'startTime')]))
  DOMAIN = dom
  // une entree par wallet : cible, solde, nonce de tx
  const W = await Promise.all(accounts.map(async a => {
    const [s, bal, n] = await retry(c => Promise.all([rdOn(c, 'state', [a.address]), c.getBalance({ address: a.address }), SEND ? c.getTransactionCount({ address: a.address, blockTag: 'pending' }) : 0]))
    return { a, target: s[4], yours: s[6], bal, nonce: n, won: 0, lastWin: 0 }
  }))
  let st = await retry(c => rdOn(c, 'state', [W[0].a.address]))
  log(`PURRCAT · ${W.length} wallet(s) · chats ${st[0] - 1n}/${max} · prix ${formatEther(st[1])} HYPE · cible de base ${bits(st[3])} bits · field ${st[5]}`)
  for (const w of W) log(`  ${short(w.a.address)} · solde ${formatEther(w.bal).slice(0, 8)} HYPE · cible ${bits(w.target)} bits (streak ${w.yours})`)
  log(SEND ? `⚠ --send : les transactions PARTENT · objectif ${COUNT === Infinity ? 'illimite' : COUNT} · prix max ${formatEther(MAX_PRICE)} HYPE · pourboire ${formatGwei(PRIO)} gwei` : 'SIMULATION : aucune transaction (ajouter --send pour tirer)')
  if (start === 0n) log('⏳ la chasse n\'a pas encore commence (startTime = 0) : on attend')

  const miner = spawn(BIN, ['--serve'], { env: minerEnv(), stdio: ['pipe', 'pipe', 'pipe'] })
  miner.on('exit', c => { log(`❌ le miner s'est arrete (code ${c}) : lancer --selftest`); process.exit(1) })
  let rate = '?'
  createInterface({ input: miner.stderr }).on('line', l => { const m = l.match(/^RATE ([\d.]+) (\d+)/); if (m) rate = m[1]; else if (!/^READY/.test(l)) log('miner :', l) })

  let job = null, jobSeq = 0, pending = false, pendingSince = 0, building = false
  let fee = await retry(c => c.getBlock()).then(b => b.baseFeePerGas ?? 100_000_000n)
  let won = 0, sent = 0, lost = 0, jobs = 0, stale = 0
  // la wallet a la cible la plus facile (a egalite : celle qui a gagne il y a le plus longtemps)
  const pick = () => [...W].sort((x, y) => (x.target === y.target ? x.lastWin - y.lastWin : (y.target > x.target ? 1 : -1)))[0]

  async function pushJob(reason) {
    if (building) return
    building = true
    try {
      const w = pick()
      const anchor = st[7] - ANCHOR_BACK
      const blk = await retry(c => c.getBlock({ blockNumber: anchor }))
      const challenge = challengeOf(blk.hash, st[2])
      const prefix = randomBytes(24).toString('hex')
      const { state, blk2 } = jobArgs(challenge, w.a.address, prefix)
      job = { id: String(++jobSeq), w, prev: st[2], anchor, challenge, target: w.target, prefix, since: Date.now() }
      jobs++; pending = false
      miner.stdin.write(`JOB ${job.id} ${state} ${blk2} ${hex64(w.target)}\n`)
      if (reason) log(`↻ ${reason} · chat #${st[0]} · ${short(w.a.address)} · ${bits(w.target)} bits`)
    } finally { building = false }
  }
  function idle() { job = null; miner.stdin.write(`JOB 0 ${'00'.repeat(200)} ${'00'.repeat(56)} ${'0'.repeat(64)}\n`) }

  // state() a chaque tick : nouveau prevWork = nouvelle course ; ancre trop vieille = nouvelle ancre
  async function tick() {
    const s = await rdOn(pc, 'state', [job?.w.a.address ?? W[0].a.address]).catch(() => null)
    if (!s || s[0] < st[0] || s[7] < st[7]) return
    st = s
    if (s[0] > max) { log('🏁 sold out : les 3333 chats sont nes'); process.exit(0) }
    if (job) job.w.target = s[4]
    if (building) return
    if (!job) return pushJob('depart')
    if (s[2] !== job.prev) { if (pending) log('prevWork a bouge pendant notre envoi'); return pushJob('nouveau chat ne') }
    if (s[7] - job.anchor > ANCHOR_REFRESH) return pushJob(null)
    if (!pending && s[4] !== job.target) return pushJob('cible changee')
    if (pending && Date.now() - pendingSince > 10000) { log('envoi sans effet depuis 10 s : on relance la recherche'); pushJob('relance') }
  }
  // cibles de toutes les wallets, moins souvent (le RPC public limite les requetes)
  async function refreshTargets() {
    if (W.length < 2) return
    for (const w of W) { const s = await rdOn(pc, 'state', [w.a.address]).catch(() => null); if (s) { w.target = s[4]; w.yours = s[6] } }
    if (job && !pending && pick() !== job.w) pushJob('wallet plus facile')
  }

  async function fire(j, n) {
    if (job && job.id !== j.id) { stale++; log('solution perimee (nouvelle course), non envoyee'); return }
    if (st[2] !== j.prev) { stale++; log('prevWork deja bouge : solution perimee'); return pushJob('nouveau chat ne') }
    if (st[7] - j.anchor > ANCHOR_MAX_SEND) { stale++; return pushJob('ancre trop vieille') }
    const price = st[1]
    if (price > MAX_PRICE) { log(`❌ prix ${formatEther(price)} > max ${formatEther(MAX_PRICE)} : on n'envoie pas (--max-price pour relever)`); process.exit(1) }
    const w = j.w
    const data = encodeFunctionData({ abi: ABI, functionName: 'mine', args: [j.anchor, n, price] })
    pending = true; pendingSince = Date.now()
    if (!SEND) {
      try { await pc.call({ account: w.a.address, to: C, data, value: price }); log(`✅ SIMULATION OK : mine() passerait (${short(w.a.address)})`) }
      catch (e) { log(`simulation : revert ${String(e.shortMessage || e.message).split('\n')[0]}`) }
      won++; if (won >= COUNT) process.exit(0); return
    }
    const signAndSend = async (nn) => {
      const raw = await w.a.signTransaction({ chainId: CHAIN_ID, type: 'eip1559', to: C, data, value: price, gas: GAS, nonce: nn, maxFeePerGas: fee * 3n + PRIO, maxPriorityFeePerGas: PRIO })
      try { return await Promise.any(senders.map(c => c.request({ method: 'eth_sendRawTransaction', params: [raw] }))) }
      catch (agg) { throw (agg.errors && agg.errors[0]) || agg }
    }
    try {
      let hash
      try { hash = await signAndSend(w.nonce++) }
      catch (e) {
        const msg = String(e.details || e.shortMessage || e.message)
        if (!/nonce/i.test(msg)) throw e
        w.nonce = await retry(c => c.getTransactionCount({ address: w.a.address, blockTag: 'pending' }))
        if (job && job.id !== j.id) { log('nonce resynchronise, mais nouvelle course : solution perimee'); return }
        log(`nonce resynchronise (${w.nonce}) : on renvoie`)
        hash = await signAndSend(w.nonce++)
      }
      sent++
      log(`→ envoye (chat #${st[0]}, ${short(w.a.address)}) ${hash}`)
      pc.waitForTransactionReceipt({ hash, timeout: 60_000, pollingInterval: 1000 }).then(rc => {
        if (rc.status === 'success') { won++; w.won++; w.lastWin = Date.now(); log(`🐱 CHAT ATTRAPE (${won}${COUNT === Infinity ? '' : '/' + COUNT}) ${short(w.a.address)} · bloc ${rc.blockNumber} · gaz ${rc.gasUsed}`); if (won >= COUNT) { log('objectif atteint'); process.exit(0) } }
        else { lost++; log(`✗ course perdue (bloc ${rc.blockNumber}) · gagnes ${won} / perdus ${lost}`) }
      }).catch(e => log('recu introuvable :', String(e.shortMessage || e.message).split('\n')[0]))
    } catch (e) {
      const msg = String(e.details || e.shortMessage || e.message).split('\n')[0]
      log('envoi echoue :', msg)
      pending = false
      const nn = await pc.getTransactionCount({ address: w.a.address, blockTag: 'pending' }).catch(() => null)
      if (nn !== null && nn !== w.nonce) { log(`nonce resynchronise ${w.nonce} -> ${nn}`); w.nonce = nn }
      if (/insufficient funds/i.test(msg)) { log(`❌ ${short(w.a.address)} : solde insuffisant pour le gaz`); process.exit(1) }
      pushJob('apres echec')
    }
  }

  createInterface({ input: miner.stdout }).on('line', l => {
    if (/^READY/.test(l)) { log(`miner pret · ${l.split(' ')[1]} GPU`); return }
    const m = l.match(/^FOUND (\S+) (\d+)/)
    if (!m) return
    const j = job
    if (!j || m[1] !== j.id || pending) return
    const n = (BigInt('0x' + j.prefix) << 64n) | BigInt(m[2])
    if (hashOf(j.challenge, j.w.a.address, n) > j.target) { log('❌ nonce refuse par viem : lancer --selftest'); return }
    log(`✅ solution trouvee en ${((Date.now() - j.since) / 1000).toFixed(1)} s`)
    fire(j, n)
  })

  if (start === 0n) { idle(); while ((await rdOn(pc, 'startTime').catch(() => 0n)) === 0n) await sleep(1000); log('🚀 la chasse est ouverte') }
  setInterval(() => tick().catch(() => {}), POLL); tick().catch(() => {})
  setInterval(() => refreshTargets().catch(() => {}), 6_000)
  setInterval(async () => { try { fee = (await pc.getBlock()).baseFeePerGas ?? fee } catch {} }, 10_000)
  setInterval(() => log(`… ${rate} GH/s · chats ${st[0] - 1n}/${max} · cible ${bits(job?.target ?? st[4])} bits · courses ${jobs} · envoyes ${sent} · gagnes ${won} · perdus ${lost} · perimes ${stale}${W.length > 1 ? ' · ' + W.map(w => short(w.a.address) + ':' + w.won).join(' ') : ''}`), 30_000)
}
main().catch(e => { console.error('FATAL', e); process.exit(1) })
